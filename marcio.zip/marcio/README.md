# backend-nodejs
Este repositório tem como objetivo de armazenar um trabalho em grupo utilizando Node.JS para desenvolver o Back-End.
